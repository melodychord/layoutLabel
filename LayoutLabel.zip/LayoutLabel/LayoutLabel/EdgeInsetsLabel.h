//
//  EdgeInsetsLabel.h
//  SNAudioGatherPro
//
//  Created by admin on 2019/6/5.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EdgeInsetsLabel : UILabel

@end

NS_ASSUME_NONNULL_END
