//
//  EdgeInsetsLabel.h
//  SNAudioGatherPro
//
//  Created by admin on 2019/6/5.
//  Copyright © 2019年 Suning. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EdgeInsetsLabel : UILabel

@end

NS_ASSUME_NONNULL_END
