//
//  ViewController.m
//  LayoutLabel
//
//  Created by Gavin on 2019/6/10.
//  Copyright © 2019年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "EdgeInsetsLabel.h"

@interface ViewController ()

// 标签
@property (nonatomic,strong) EdgeInsetsLabel *Label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.Label];
    //给定最大的尺寸
    CGSize maxSize = CGSizeMake([UIScreen mainScreen].bounds.size.width-2*22, 200);
    //根据字体级文字内容多少显示  (根据后台返回字数不定，但有最大字数限制)
    NSString *textContent = @"字数不定字数不定字数不定字数不定字数不定字数不定字数不定字数不定字数不定字数不定";
    _Label.text = textContent;
    CGSize size = [_Label.text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:18]} context:nil].size;
    _Label.frame = CGRectMake(22,120,[UIScreen mainScreen].bounds.size.width-2*22,size.height+20);
    _Label.font = [UIFont systemFontOfSize:18];
    // Do any additional setup after loading the view, typically from a nib.
}

- (UILabel *)Label{
    if(!_Label){
        //自定义的Label,自带内边距
        _Label = [[EdgeInsetsLabel alloc] init];
        _Label.numberOfLines = 0;
        _Label.lineBreakMode = NSLineBreakByTruncatingTail;
        _Label.layer.borderWidth = 1;
        _Label.layer.borderColor = [UIColor colorWithRed:0.29 green:0.39 blue:0.56 alpha:1.00].CGColor;
        _Label.layer.cornerRadius = 5;
        _Label.layer.masksToBounds = YES;
        _Label.clipsToBounds = YES;
        _Label.textColor = [UIColor purpleColor];
        _Label.textAlignment = NSTextAlignmentCenter;

    }
    return _Label;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
