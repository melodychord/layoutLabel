//
//  EdgeInsetsLabel.m
//  SNAudioGatherPro
//
//  Created by admin on 2019/6/5.
//  Copyright © 2019年 Suning. All rights reserved.
//

#import "EdgeInsetsLabel.h"

@interface EdgeInsetsLabel ()

//内边距
@property (assign,nonatomic) UIEdgeInsets edgeInsets;

@end

@implementation EdgeInsetsLabel

- (instancetype)init
{
    if(self = [super init])
    {
        self.edgeInsets = UIEdgeInsetsMake(10,5,10,5);
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        self.edgeInsets = UIEdgeInsetsMake(10,5,10,5);
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super initWithCoder:aDecoder])
    {
        self.edgeInsets = UIEdgeInsetsMake(10,5,10,5);
    }
    return self;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.edgeInsets = UIEdgeInsetsMake(10,5,10,5);
}

//重写系统方法
- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines{
    CGRect rect = [super textRectForBounds:UIEdgeInsetsInsetRect(bounds,self.edgeInsets) limitedToNumberOfLines:numberOfLines];
    rect.origin.x -= self.edgeInsets.left;
    rect.origin.y -= self.edgeInsets.top;
    rect.size.width += self.edgeInsets.left + self.edgeInsets.right;
    rect.size.height += self.edgeInsets.top + self.edgeInsets.bottom;
    return rect;
}

// //绘制文字
- (void)drawTextInRect:(CGRect)rect
{
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect,self.edgeInsets)];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
